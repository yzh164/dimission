# 数据库表结构

## 评价设置

```
CREATE TABLE `wb_auto_rate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '开启状态',
  `listen_event` varchar(45) DEFAULT NULL COMMENT '监听的事件，订单完成或买家评价',
  `time_out` varchar(45) DEFAULT NULL COMMENT '超时评价，单位天',
  `content_pattern` varchar(10) DEFAULT NULL COMMENT '评语选择模式：随机(random)，默认(default)',
  `no_rate_blacklist` varchar(45) DEFAULT NULL COMMENT '不评价黑名单',
  `tate_type` varchar(45) DEFAULT NULL COMMENT '评价类型',
  `add_blacklist_condition` varchar(45) DEFAULT NULL COMMENT '添加黑名单的条件：不添加，中评，差评',
  `add_to_other_blacklist` varchar(45) DEFAULT NULL COMMENT '添加到其他的黑名单：购买黑名单，短信黑名单',
  `blacklist_rate_type` varchar(10) DEFAULT NULL COMMENT '黑名单评价类型',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `remark` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
```

## 评价内容

```
CREATE TABLE `wb_auto_rate_content` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `content` varchar(600) NOT NULL COMMENT '评价内容',
  `rate_user_type` varchar(45) DEFAULT NULL COMMENT '评价用户类型：普通，黑名单',
  `def` tinyint(1) DEFAULT NULL COMMENT '默认评语',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `remark` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
```

## 评价记录

```
CREATE TABLE `wb_auto_rate_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `tid` varchar(45) NOT NULL COMMENT '交易编号',
  `oid` varchar(45) DEFAULT NULL COMMENT '订单编号',
  `process_type` varchar(45) DEFAULT NULL COMMENT '程序处理类型',
  `buyer_nick` varchar(255) DEFAULT NULL COMMENT '买家昵称',
  `content` varchar(600) DEFAULT NULL COMMENT '评价内容',
  `rate_type` varchar(10) NOT NULL COMMENT '评价类型',
  `success` tinyint(1) NOT NULL COMMENT '评价结果',
  `msg` varchar(255) DEFAULT NULL COMMENT '错误信息',
  `remark` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
```

## 评价黑名单

```
CREATE TABLE `wb_auto_rate_user_blacklist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `buyer_nick` varchar(255) NOT NULL COMMENT '买家昵称',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `remark` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
```

## 订单评价检索位置

```
CREATE TABLE `wb_rate_api_scan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `trade_end_time` datetime DEFAULT NULL COMMENT '用于 taobao.trades.sold.get 接口的参数 end_created，缩小查询范围',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
```

## 订单评价状态

```
CREATE TABLE `wb_rate_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `tid` bigint(20) NOT NULL,
  `oid` bigint(20) DEFAULT NULL,
  `topic` varchar(45) NOT NULL COMMENT 'ONS 消息主题',
  `seller_can_rate` tinyint(1) DEFAULT NULL COMMENT '卖家是否可以评价',
  `seller_rate` tinyint(1) DEFAULT NULL COMMENT '卖家是否已经评价',
  `buyer_rate` tinyint(1) DEFAULT NULL COMMENT '卖家是否已经评价',
  `trade_end_time` datetime DEFAULT NULL COMMENT '交易结束时间',
  `order_end_time` datetime DEFAULT NULL COMMENT '子订单的交易结束时间',
  `remark` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
```
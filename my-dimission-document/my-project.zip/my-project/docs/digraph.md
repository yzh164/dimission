# digraph源码

## rateAll
```
digraph G {
    node [shape=box];
    subgraph cluster0 {
		edge [color=DodgerBlue];
        ONS -> { taobao_trade_TradeSuccess; taobao_trade_TradeRated};
        rate [label="执行评价"];
        node [shape="diamond"];
        eqa [label="设置的是立即评价"];
        eqb [label="设置的是买家评价后评价"];
        taobao_trade_TradeSuccess -> eqa -> rate;
        taobao_trade_TradeRated -> eqb -> rate;
    }
    subgraph cluster1 {
		edge [color=DodgerBlue];
        rateSetting [label="获取开启自动评价的设置"];
        a [label="立即评价"];
        b [label="买家评价后评价"];
        c [label="确定收货第七天评价"];
        d [label="最后时间评价"];
        e [label="买家评价后评价，\n确定收货第七天评价"]
        f [label="买家评价后评价，\n最后时间评价"]
        qruc [label="查询RATE_UNSELLER的订单并执行评价"];
        qru [label="查询RATE_UNSELLER的订单"];
        qrbuc [label="查询RATE_BUYER_UNSELLER的订单并执行评价"];
        rateSetting -> { a; b; c; d; e; f};
        a -> qruc;
        b -> qrbuc;
        c -> qru;
        d -> qru;
        e -> { qru; qrbuc};
        f -> { qru; qrbuc};
    }
    subgraph cluster2 {
		edge [color=DodgerBlue];
        h [label="查询开启确定收货第七天评价的用户"];
        i [label="查询开启最后时间评价的用户"];
        j [label="查询wb_rate_status表中\n6天前可以评价的订单"];
        k [label="查询wb_rate_status表中\n14天前可以评价的订单"];
        execute2 [label="执行评价，更新wb_rate_status"];
        h -> j -> execute2;
        i -> k -> execute2;
    }
	edge [color=Chartreuse];
    saveRateStatus [label="保存订单信息到 wb_rate_status 表"];
    saveApiScanTime [label="保存 end_created 参数到 wb_rate_api_scan.trade_end_time"];
    qru -> saveApiScanTime;
    qru -> saveRateStatus;
    taobao_trade_TradeSuccess -> saveRateStatus;
	edge [color=red];
	node [shape=box,style=filled,color=".7 .3 1.0"];
	saveRateRecord [label="保存评价记录"];
	rate -> saveRateRecord;
	qruc -> saveRateRecord;
	qrbuc -> saveRateRecord;
	execute2 -> saveRateRecord;
}
```

## api
```
digraph G {
    node [shape=box];
    subgraph cluster1 {
		edge [color=DodgerBlue];
        rateSetting [label="获取开启自动评价的设置"];
        a [label="立即评价"];
        b [label="买家评价后评价"];
        c [label="确定收货第七天评价"];
        d [label="最后时间评价"];
        e [label="买家评价后评价，\n确定收货第七天评价"]
        f [label="买家评价后评价，\n最后时间评价"]
        qruc [label="查询RATE_UNSELLER的订单并执行评价"];
        qru [label="查询RATE_UNSELLER的订单"];
        qrbuc [label="查询RATE_BUYER_UNSELLER的订单并执行评价"];
        rateSetting -> { a; b; c; d; e; f};
        a -> qruc;
        b -> qrbuc;
        c -> qru;
        d -> qru;
        e -> { qru; qrbuc};
        f -> { qru; qrbuc};
    }
	edge [color=Chartreuse];
    saveRateStatus [label="保存订单信息到 wb_rate_status 表"];
    saveApiScanTime [label="保存 end_created 参数到 wb_rate_api_scan.trade_end_time"];
    qru -> saveApiScanTime;
    qru -> saveRateStatus;
	edge [color=red];
	node [shape=box,style=filled,color=".7 .3 1.0"];
	saveRateRecord [label="保存评价记录"];
	qruc -> saveRateRecord;
	qrbuc -> saveRateRecord;
}
```

## rds
```
digraph G {
    subgraph cluster2 {
		edge [color=DodgerBlue];
        h [label="查询开启确定收货第七天评价的用户"];
        i [label="查询开启最后时间评价的用户"];
        j [label="查询wb_rate_status表中\n6天前可以评价的订单"];
        k [label="查询wb_rate_status表中\n14天前可以评价的订单"];
        execute2 [label="执行评价，更新wb_rate_status"];
        h -> j -> execute2;
        i -> k -> execute2;
    }
	edge [color=red];
	node [shape=box,style=filled,color=".7 .3 1.0"];
	saveRateRecord [label="保存评价记录"];
	execute2 -> saveRateRecord;
}
```

## ons
```
digraph G {
    node [shape=box];
    subgraph cluster0 {
		edge [color=DodgerBlue];
        ONS -> { taobao_trade_TradeSuccess; taobao_trade_TradeRated};
        rate [label="执行评价"];
        node [shape="diamond"];
        eqa [label="设置的是立即评价"];
        eqb [label="设置的是买家评价后评价"];
        taobao_trade_TradeSuccess -> eqa -> rate;
        taobao_trade_TradeRated -> eqb -> rate;
    }
	edge [color=Chartreuse];
    saveRateStatus [label="保存订单信息到 wb_rate_status 表"];
    taobao_trade_TradeSuccess -> saveRateStatus;
	edge [color=red];
	node [shape=box,style=filled,color=".7 .3 1.0"];
	saveRateRecord [label="保存评价记录"];
	rate -> saveRateRecord;
}
```

## rateAPI
```
digraph G {
    node [shape=box];
    subgraph cluster1 {
		edge [color=DodgerBlue];
        rateSetting [label="获取有开启自动评价设置的评价设置"];
		commentNowRate [label="立即评价"];
		buyerRate [label="买家评价后评价"];
		timeOutRate [label="超时评价"];
		node [shape=diamond];
        isEmptyRate [label="判断自动评价设置信息是否为空"];
		node [shape=box];
		user [label="获取用户信息"];
		tradesSold [label="获取交易列表"];
		node [shape=diamond];
		isEmptyTradesSold [label="判断交易列表是否为空"];
		node [shape=box];
		blackList [label="获取黑名单列表"];
		autoRateContent [label="获取评价内容"];
		node [shape=diamond];
		mayRate [label="判断该交易是否\n属于可评价交易"];
		mayRateTimeOut [label="判断该交易是否\n属于可评价交易[超时评价]"];
		equalsBlackList [label="判断是否是黑名单用户"];
		node [shape=box];
		executeAddTraderate [label="执行评价"];
		saveWbAutoRateRecord [label="保存评价记录"];
		saveWbRateApiScan [label="保存订单评价检索位置"];
		saveWbRateStatus [label="保存订单评价状态"];
		
		rateSetting -> commentNowRate;
		rateSetting -> buyerRate;
		rateSetting -> timeOutRate;
		commentNowRate -> isEmptyRate;
		buyerRate -> isEmptyRate;
		timeOutRate -> isEmptyRate;
		isEmptyRate -> user;
		user -> tradesSold;
		tradesSold -> isEmptyTradesSold;
		isEmptyTradesSold -> blackList;
		isEmptyTradesSold -> mayRateTimeOut [label="超时评价"];
		mayRateTimeOut ->saveWbRateApiScan;
		mayRateTimeOut -> saveWbRateStatus;
		blackList -> autoRateContent;
		autoRateContent -> mayRate;
		mayRate -> equalsBlackList;
		equalsBlackList -> executeAddTraderate;
		executeAddTraderate -> saveWbAutoRateRecord;
    }
}
```

## rateRDS
```
digraph G {
    node [shape=box];
    subgraph cluster1 {
		edge [color=DodgerBlue];
        rateSetting [label="获取有开启自动评价设置的评价设置"];
		sevenDays [label="确认收货第七天评价的评价设置"];
		lastTime [label="最后时间评价的评价设置"];
		node [shape=diamond];
        isEmptyRate [label="判断自动评价设置信息是否为空"];
		node [shape=box];
		user [label="获取用户信息"];
		rateStatusList [label="获取订单评价状态表数据"];
		blackList [label="获取黑名单用户列表"];
		autoRateContentList [label="获取评价内容列表"];
		node [shape=diamond];
		mayRate [label="判断该交易是否\n属于可评价交易"];
		equalsBlackList [label="判断是否是黑名单用户"];
		node [shape=box];
		executeAddTraderate [label="执行评价"];
		updateRateStatus [label="修改订单评价状态表状态"];
		saveWbAutoRateRecord [label="保存评价记录"];
		
		rateSetting -> sevenDays;
		rateSetting -> lastTime;
		sevenDays -> isEmptyRate;
		lastTime -> isEmptyRate;
		isEmptyRate -> user;
		user -> rateStatusList;
		rateStatusList -> blackList;
		blackList -> autoRateContentList;
		autoRateContentList -> mayRate;
		mayRate -> equalsBlackList;
		equalsBlackList -> executeAddTraderate;
		executeAddTraderate -> updateRateStatus;
		updateRateStatus -> saveWbAutoRateRecord;
    }
}
```

## rateONS
```
```

## rateService
```
digraph G {
    node [shape=box];
    subgraph cluster1 {
		edge [color=DodgerBlue];
        rateSetting [label="获取有开启自动评价设置的评价设置"];
		node [shape=diamond];
        isEmpty [label="判断获取自动评价\n设置信息是否为空"];
		node [shape=box];
		user [label="获取用户信息"];
		trades [label="获取交易信息"];
		node [shape=diamond];
		isSuccess [label="判断交易信息列表是否为空"];
		node [shape=box];
		orderLog [label="上传日志订单"];
		blackList [label="获取黑名单列表"];
		contentList [label="评价内容列表"];
		node [shape=diamond];
		isSellerCanRate [label="判断卖家是否可以评价"];
		isNoRateBlackUser [label="判断该用户是否是黑名单用户"];
		isCanRate [label="判断该笔交易是否在可评价时间内"];
		isTidRate [label="判断该笔交易是否评价过"];
		node [shape=box];
		addTraderRate [label="执行评价"];
		saveRateRecord [label="保存评价记录"];
		
		rateSetting -> isEmpty;
		isEmpty -> user;
		user -> trades;
		trades -> isSuccess;
		isSuccess -> orderLog;
		orderLog -> blackList;
		blackList -> contentList;
		contentList -> isSellerCanRate;
		isSellerCanRate -> isNoRateBlackUser;
		isNoRateBlackUser -> isCanRate;
		isCanRate -> isTidRate;
		isTidRate -> addTraderRate;
		addTraderRate->saveRateRecord;
    }
}
```

## addRateBlack
```
digraph G {
    node [shape=box];
    subgraph cluster1 {
		edge [color=DodgerBlue];
        rateSetting [label="获取开启自动评价并设置添加\n黑名单的用户信息和自动评价设置"];
		node [shape=diamond];
        isEmpty [label="判断获取自动评价\n设置信息是否为空"];
		node [shape=box];
		user [label="获取用户信息"];
		blackList [label="获取黑名单列表"];
		node [shape=diamond];
		equals [label="短信(|,&)差评防御黑名单"];
		node [shape=box];
		smsAnddsr [label="获取短信&差评防御黑名单"];
		sms [label="获取短信黑名单"];
		dsr [label="获取差评防御黑名单"];
		importBlackListBad [label="导入六个月内的差评总数"];
		node [shape=diamond];
		equalsNeutral [label="判断评价是否添加条件是中评？"];
		node [shape=box];
		importBlackListNeutral [label="导入六个月内的差评总数"];
		
		
		rateSetting -> isEmpty;
		isEmpty -> user;
		user -> blackList;
		blackList -> equals;
		equals -> smsAnddsr;
		equals -> sms;
		equals -> dsr;
		smsAnddsr -> importBlackListBad;
		sms -> importBlackListBad;
		dsr -> importBlackListBad;
		importBlackListBad -> equalsNeutral;
		equalsNeutral -> importBlackListNeutral;
    }
}
```
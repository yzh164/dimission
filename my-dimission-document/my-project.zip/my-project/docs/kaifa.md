# 开发补充

## 程序入口三个
分别是 API、ONS、RDS，三个分别是程序的三个
<h2>API</h2>
![Screenshot](img/api.svg)
<h2>ONS</h2>
![Screenshot](img/ons.svg)
<h2>RDS</h2>
![Screenshot](img/rds.svg)


## 获取开启自动评价（API）

![Screenshot](img/api.svg)
获取数据库（wb_after_sales）表（wb_auto_rate）中的有开启自动评价状态（数据库表列名:status）的自动评价设置信息。

再根据获取的自动评价设置的信息 分出三种分别是：<font style="color:red">立即评价</font>、<font style="color:DeepSkyBlue">买家评价后评价</font>、<font style="color:	Orange">超时评价</font>，分别执行<font style="color:red">查询 RATE_UNSELLER（买家未评） 的订单执行评价</font>、<font style="color:DeepSkyBlue">查询RATE_BUYER_UNSELLER（买家已评，卖家未评） 的订单执行评价</font>、<font style="color:Orange">查询 RAYE_UNSELLER（买家未评） 的订单信息保存到 wb_rate_status 表，保存 end_create 参数到 wb_rate_api_scan.trade_end_time</font>


调用API进行查询对应状态的订单进行评价


调用API执行评价后<font style="color:DeepSkyBlue">立即评价、买家评价后评价两种评价设置评价后保存评价记录</font>，<font style="color:	DeepPink">超时评价将查询的订单信息保存到 wb_rate_status 表，保存 end_create 参数到 wb_rate_api_scan.trade_end_time</font>
<br/>
<br/>

## 从数据库获取信息进行评价（RDS）

![Screenshot](img/rds.svg)
从评价设置表获取有设置超时评价的用户，查询wb_rate_status表中6天前、14天前可以评价的订单，执行评价，更新wb_rate_status状态，并保存评价记录
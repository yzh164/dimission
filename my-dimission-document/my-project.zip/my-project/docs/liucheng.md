# 18 新版自动评价流程图

## API评价流程
![Screenshot](img/rateAPI.svg)

## RDS评价流程图
![Screenshot](img/rateRDS.svg)

## 根据USERID进行自动评价
![Screenshot](img/rateService.svg)

## 添加黑名单用户
![Screenshot](img/addRateBlack.svg)
